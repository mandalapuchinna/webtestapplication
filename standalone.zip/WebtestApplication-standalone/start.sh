#!/bin/bash
WA_HOME=$PWD
TOMCAT_HOME=$WA_HOME/apache-tomcat-7.0.55
WEBTEST_HOME=$WA_HOME/webtest-3.0.1826
STORAGE_HOME=$WA_HOME/webtest-reports
HSQL_HOME=$WA_HOME/hsqldb-2.3.2

### set permissions ###
cd $TOMCAT_HOME/bin && chmod +x *.sh
cd $WEBTEST_HOME/bin && chmod +x *.sh
cd $HSQL_HOME/bin && chmod +x *.sh

### modify storage docbase ###
sed -i "s,docBase='[^']*',docBase='$STORAGE_HOME',g" $TOMCAT_HOME/conf/server.xml

### start HSQL database ###
cd $HSQL_HOME/data
gnome-terminal -x ../bin/runServer.sh -database.0 file:webtest -dbname.0 webtest

### start tomcat server ###
cd $TOMCAT_HOME/bin
gnome-terminal -x ./catalina.sh run

### start application ###
xdg-open "http://localhost:8181/WebtestApplication"